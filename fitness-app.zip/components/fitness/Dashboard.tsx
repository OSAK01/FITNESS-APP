"use client"

import { useState } from 'react'
import { motion } from 'framer-motion'
import { DndProvider } from 'react-dnd'
import { HTML5Backend } from 'react-dnd-html5-backend'
import { CalorieWidget } from './CalorieWidget'
import { StepsWidget } from './StepsWidget'
import { WaterWidget } from './WaterWidget'
import { WeightWidget } from './WeightWidget'
import { WorkoutWidget } from './WorkoutWidget'
import { DraggableWidget } from './DraggableWidget'
import { Settings, Grid3X3, List } from 'lucide-react'

interface Widget {
  id: string
  type: string
  component: React.ReactNode
  title: string
}

export function Dashboard() {
  console.log("Dashboard component rendered")

  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [widgets, setWidgets] = useState<Widget[]>([
    { 
      id: 'calories', 
      type: 'calorie', 
      component: <CalorieWidget />, 
      title: 'Calorie Tracker' 
    },
    { 
      id: 'steps', 
      type: 'steps', 
      component: <StepsWidget />, 
      title: 'Daily Steps' 
    },
    { 
      id: 'water', 
      type: 'water', 
      component: <WaterWidget />, 
      title: 'Water Intake' 
    },
    { 
      id: 'weight', 
      type: 'weight', 
      component: <WeightWidget />, 
      title: 'Weight Progress' 
    },
    { 
      id: 'workout', 
      type: 'workout', 
      component: <WorkoutWidget />, 
      title: 'Workout Log' 
    },
  ])

  const moveWidget = (dragIndex: number, hoverIndex: number) => {
    console.log("Moving widget:", { dragIndex, hoverIndex })
    const draggedWidget = widgets[dragIndex]
    const newWidgets = [...widgets]
    newWidgets.splice(dragIndex, 1)
    newWidgets.splice(hoverIndex, 0, draggedWidget)
    setWidgets(newWidgets)
  }

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="min-h-screen bg-gradient-to-br from-fitness-light to-white">
        {/* Header */}
        <motion.div 
          className="bg-white shadow-sm border-b border-gray-200 px-6 py-4"
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
        >
          <div className="flex justify-between items-center max-w-7xl mx-auto">
            <div>
              <h1 className="text-3xl font-bold text-fitness-text">
                Your Fitness Dashboard
              </h1>
              <p className="text-fitness-text/60 mt-1">
                Customize your view and track your health journey
              </p>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex bg-gray-100 rounded-lg p-1">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 rounded-md transition-colors ${
                    viewMode === 'grid' 
                      ? 'bg-fitness-primary text-white' 
                      : 'text-fitness-text hover:bg-gray-200'
                  }`}
                >
                  <Grid3X3 size={20} />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded-md transition-colors ${
                    viewMode === 'list' 
                      ? 'bg-fitness-primary text-white' 
                      : 'text-fitness-text hover:bg-gray-200'
                  }`}
                >
                  <List size={20} />
                </button>
              </div>
              
              <button className="p-2 text-fitness-text hover:bg-gray-100 rounded-lg transition-colors">
                <Settings size={24} />
              </button>
            </div>
          </div>
        </motion.div>

        {/* Widgets Container */}
        <div className="max-w-7xl mx-auto p-6">
          <motion.div 
            className={`${
              viewMode === 'grid' 
                ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' 
                : 'space-y-4'
            }`}
            layout
          >
            {widgets.map((widget, index) => (
              <DraggableWidget
                key={widget.id}
                id={widget.id}
                index={index}
                moveWidget={moveWidget}
                viewMode={viewMode}
              >
                {widget.component}
              </DraggableWidget>
            ))}
          </motion.div>
        </div>
      </div>
    </DndProvider>
  )
}