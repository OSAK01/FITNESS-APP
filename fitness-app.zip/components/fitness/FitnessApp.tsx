"use client"

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Home, BookOpen, Settings, User } from 'lucide-react'
import { Dashboard } from './Dashboard'
import { BlogSection } from './BlogSection'

type View = 'dashboard' | 'blog' | 'profile' | 'settings'

export function FitnessApp() {
  console.log("FitnessApp component rendered")

  const [activeView, setActiveView] = useState<View>('dashboard')

  const navItems = [
    { id: 'dashboard' as View, label: 'Dashboard', icon: Home },
    { id: 'blog' as View, label: 'Blog', icon: BookOpen },
    { id: 'profile' as View, label: 'Profile', icon: User },
    { id: 'settings' as View, label: 'Settings', icon: Settings },
  ]

  const renderContent = () => {
    switch (activeView) {
      case 'dashboard':
        return <Dashboard />
      case 'blog':
        return <BlogSection />
      case 'profile':
        return <ProfileView />
      case 'settings':
        return <SettingsView />
      default:
        return <Dashboard />
    }
  }

  return (
    <div className="min-h-screen bg-fitness-background">
      {/* Navigation */}
      <motion.nav 
        className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2 z-50 md:top-0 md:bottom-auto md:border-t-0 md:border-b"
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-around md:justify-start md:space-x-8">
            {navItems.map((item) => {
              const Icon = item.icon
              const isActive = activeView === item.id
              
              return (
                <motion.button
                  key={item.id}
                  onClick={() => setActiveView(item.id)}
                  className={`flex flex-col md:flex-row items-center space-y-1 md:space-y-0 md:space-x-2 p-2 rounded-lg transition-colors ${
                    isActive 
                      ? 'text-fitness-primary bg-fitness-primary/10' 
                      : 'text-fitness-text/60 hover:text-fitness-primary hover:bg-fitness-primary/5'
                  }`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Icon size={20} />
                  <span className="text-xs md:text-sm font-medium">{item.label}</span>
                </motion.button>
              )
            })}
          </div>
        </div>
      </motion.nav>

      {/* Content */}
      <div className="pb-20 md:pb-0 md:pt-20">
        <motion.div
          key={activeView}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
        >
          {renderContent()}
        </motion.div>
      </div>
    </div>
  )
}

function ProfileView() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-fitness-light to-white flex items-center justify-center">
      <motion.div 
        className="text-center"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
      >
        <div className="w-24 h-24 bg-fitness-primary/20 rounded-full mx-auto mb-4 flex items-center justify-center">
          <User size={32} className="text-fitness-primary" />
        </div>
        <h2 className="text-2xl font-bold text-fitness-text mb-2">Profile Section</h2>
        <p className="text-fitness-text/60">Track your personal fitness journey and achievements</p>
      </motion.div>
    </div>
  )
}

function SettingsView() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-fitness-light to-white flex items-center justify-center">
      <motion.div 
        className="text-center"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
      >
        <div className="w-24 h-24 bg-fitness-secondary/20 rounded-full mx-auto mb-4 flex items-center justify-center">
          <Settings size={32} className="text-fitness-secondary" />
        </div>
        <h2 className="text-2xl font-bold text-fitness-text mb-2">Settings</h2>
        <p className="text-fitness-text/60">Customize your app experience and preferences</p>
      </motion.div>
    </div>
  )
}