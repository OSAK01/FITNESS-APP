"use client"

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Plus, Utensils, Target } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

interface Food {
  id: string
  name: string
  calories: number
  time: string
}

export function CalorieWidget() {
  console.log("CalorieWidget component rendered")

  const [foods, setFoods] = useState<Food[]>([
    { id: '1', name: 'Oatmeal with berries', calories: 320, time: '08:30' },
    { id: '2', name: 'Grilled chicken salad', calories: 450, time: '12:45' },
    { id: '3', name: 'Greek yogurt', calories: 150, time: '15:20' },
  ])

  const [newFood, setNewFood] = useState({ name: '', calories: '' })
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const totalCalories = foods.reduce((sum, food) => sum + food.calories, 0)
  const dailyGoal = 2000
  const progress = (totalCalories / dailyGoal) * 100

  const addFood = () => {
    if (newFood.name && newFood.calories) {
      console.log("Adding new food:", newFood)
      const food: Food = {
        id: Date.now().toString(),
        name: newFood.name,
        calories: parseInt(newFood.calories),
        time: new Date().toLocaleTimeString('en-US', { 
          hour: '2-digit', 
          minute: '2-digit' 
        })
      }
      setFoods([...foods, food])
      setNewFood({ name: '', calories: '' })
      setIsDialogOpen(false)
    }
  }

  return (
    <motion.div 
      className="bg-white rounded-xl shadow-lg p-6 border border-gray-100"
      whileHover={{ y: -2 }}
      transition={{ duration: 0.2 }}
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="bg-fitness-primary/10 p-2 rounded-lg">
            <Utensils className="text-fitness-primary" size={24} />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-fitness-text">Calorie Tracker</h3>
            <p className="text-sm text-fitness-text/60">Track your daily intake</p>
          </div>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="bg-fitness-primary hover:bg-fitness-primary/90">
              <Plus size={16} />
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Food</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="foodName">Food Name</Label>
                <Input
                  id="foodName"
                  value={newFood.name}
                  onChange={(e) => setNewFood({ ...newFood, name: e.target.value })}
                  placeholder="e.g., Grilled chicken breast"
                />
              </div>
              <div>
                <Label htmlFor="calories">Calories</Label>
                <Input
                  id="calories"
                  type="number"
                  value={newFood.calories}
                  onChange={(e) => setNewFood({ ...newFood, calories: e.target.value })}
                  placeholder="e.g., 250"
                />
              </div>
              <Button onClick={addFood} className="w-full bg-fitness-primary hover:bg-fitness-primary/90">
                Add Food
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Progress Ring */}
      <div className="flex items-center justify-center mb-6">
        <div className="relative w-32 h-32">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              r="40"
              stroke="#e5e7eb"
              strokeWidth="8"
              fill="none"
            />
            <motion.circle
              cx="50"
              cy="50"
              r="40"
              stroke="#22c55e"
              strokeWidth="8"
              fill="none"
              strokeLinecap="round"
              strokeDasharray="251.2"
              initial={{ strokeDashoffset: 251.2 }}
              animate={{ strokeDashoffset: 251.2 - (251.2 * progress) / 100 }}
              transition={{ duration: 1, ease: "easeOut" }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-2xl font-bold text-fitness-text">{totalCalories}</span>
            <span className="text-xs text-fitness-text/60">of {dailyGoal}</span>
          </div>
        </div>
      </div>

      {/* Goal Status */}
      <div className="flex items-center justify-center mb-4 space-x-2">
        <Target size={16} className="text-fitness-primary" />
        <span className="text-sm text-fitness-text/80">
          {dailyGoal - totalCalories > 0 
            ? `${dailyGoal - totalCalories} calories remaining`
            : `${totalCalories - dailyGoal} calories over goal`
          }
        </span>
      </div>

      {/* Recent Foods */}
      <div className="space-y-2">
        <h4 className="text-sm font-medium text-fitness-text/80">Recent Meals</h4>
        {foods.slice(-3).map((food) => (
          <motion.div 
            key={food.id}
            className="flex justify-between items-center p-2 bg-gray-50 rounded-lg"
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
          >
            <div>
              <p className="text-sm font-medium text-fitness-text">{food.name}</p>
              <p className="text-xs text-fitness-text/60">{food.time}</p>
            </div>
            <span className="text-sm font-semibold text-fitness-primary">
              {food.calories} cal
            </span>
          </motion.div>
        ))}
      </div>
    </motion.div>
  )
}