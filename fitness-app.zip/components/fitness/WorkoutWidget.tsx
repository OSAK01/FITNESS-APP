"use client"

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Dumbbell, Play, Clock } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface Workout {
  id: string
  name: string
  duration: string
  exercises: number
  difficulty: 'Easy' | 'Medium' | 'Hard'
}

export function WorkoutWidget() {
  console.log("WorkoutWidget component rendered")

  const [workouts] = useState<Workout[]>([
    { 
      id: '1', 
      name: 'Upper Body Strength', 
      duration: '45 min', 
      exercises: 8, 
      difficulty: 'Medium' 
    },
    { 
      id: '2', 
      name: 'HIIT Cardio Blast', 
      duration: '30 min', 
      exercises: 6, 
      difficulty: 'Hard' 
    },
    { 
      id: '3', 
      name: 'Morning Yoga Flow', 
      duration: '25 min', 
      exercises: 12, 
      difficulty: 'Easy' 
    },
  ])

  const [selectedWorkout, setSelectedWorkout] = useState(workouts[0])

  const difficultyColors = {
    Easy: 'text-green-500 bg-green-50',
    Medium: 'text-yellow-500 bg-yellow-50', 
    Hard: 'text-red-500 bg-red-50'
  }

  const startWorkout = () => {
    console.log("Starting workout:", selectedWorkout.name)
    // Workout logic would go here
  }

  return (
    <motion.div 
      className="bg-white rounded-xl shadow-lg p-6 border border-gray-100"
      whileHover={{ y: -2 }}
      transition={{ duration: 0.2 }}
    >
      <div className="flex items-center space-x-3 mb-4">
        <div className="bg-fitness-primary/10 p-2 rounded-lg">
          <Dumbbell className="text-fitness-primary" size={24} />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-fitness-text">Today's Workout</h3>
          <p className="text-sm text-fitness-text/60">Stay consistent</p>
        </div>
      </div>

      {/* Selected Workout */}
      <motion.div 
        className="bg-gradient-to-r from-fitness-primary/5 to-fitness-secondary/5 rounded-lg p-4 mb-4"
        key={selectedWorkout.id}
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
      >
        <div className="flex justify-between items-start mb-3">
          <h4 className="text-lg font-semibold text-fitness-text">
            {selectedWorkout.name}
          </h4>
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${difficultyColors[selectedWorkout.difficulty]}`}>
            {selectedWorkout.difficulty}
          </span>
        </div>
        
        <div className="flex items-center space-x-4 text-sm text-fitness-text/70 mb-4">
          <div className="flex items-center space-x-1">
            <Clock size={14} />
            <span>{selectedWorkout.duration}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Dumbbell size={14} />
            <span>{selectedWorkout.exercises} exercises</span>
          </div>
        </div>

        <Button 
          onClick={startWorkout}
          className="w-full bg-fitness-primary hover:bg-fitness-primary/90"
        >
          <Play size={16} className="mr-2" />
          Start Workout
        </Button>
      </motion.div>

      {/* Other Workouts */}
      <div className="space-y-2">
        <h5 className="text-sm font-medium text-fitness-text/80 mb-2">Other Options</h5>
        {workouts.filter(w => w.id !== selectedWorkout.id).map((workout) => (
          <motion.button
            key={workout.id}
            onClick={() => setSelectedWorkout(workout)}
            className="w-full text-left p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
            whileHover={{ x: 4 }}
          >
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-fitness-text">{workout.name}</p>
                <p className="text-xs text-fitness-text/60">
                  {workout.duration} • {workout.exercises} exercises
                </p>
              </div>
              <span className={`px-2 py-1 rounded-full text-xs ${difficultyColors[workout.difficulty]}`}>
                {workout.difficulty}
              </span>
            </div>
          </motion.button>
        ))}
      </div>
    </motion.div>
  )
}