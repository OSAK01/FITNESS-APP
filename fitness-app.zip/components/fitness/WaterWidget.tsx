"use client"

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Droplets, Plus, Minus } from 'lucide-react'

export function WaterWidget() {
  console.log("WaterWidget component rendered")

  const [glasses, setGlasses] = useState(6)
  const dailyGoal = 8
  const progress = (glasses / dailyGoal) * 100

  const addGlass = () => {
    console.log("Adding water glass")
    setGlasses(prev => Math.min(prev + 1, 12))
  }

  const removeGlass = () => {
    console.log("Removing water glass")
    setGlasses(prev => Math.max(prev - 1, 0))
  }

  return (
    <motion.div 
      className="bg-white rounded-xl shadow-lg p-6 border border-gray-100"
      whileHover={{ y: -2 }}
      transition={{ duration: 0.2 }}
    >
      <div className="flex items-center space-x-3 mb-4">
        <div className="bg-blue-500/10 p-2 rounded-lg">
          <Droplets className="text-blue-500" size={24} />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-fitness-text">Water Intake</h3>
          <p className="text-sm text-fitness-text/60">Stay hydrated</p>
        </div>
      </div>

      <div className="text-center mb-6">
        <motion.div 
          className="text-3xl font-bold text-blue-500 mb-1"
          key={glasses}
          initial={{ scale: 1.2 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.3 }}
        >
          {glasses}
        </motion.div>
        <div className="text-sm text-fitness-text/60">of {dailyGoal} glasses</div>
      </div>

      {/* Water Glasses Visual */}
      <div className="grid grid-cols-4 gap-2 mb-6">
        {Array.from({ length: dailyGoal }, (_, i) => (
          <motion.div
            key={i}
            className={`h-8 rounded-t-lg border-2 ${
              i < glasses 
                ? 'bg-blue-500 border-blue-500' 
                : 'border-gray-300'
            }`}
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: i * 0.1 }}
          >
            {i < glasses && (
              <motion.div
                className="h-full bg-blue-400 rounded-t-sm"
                initial={{ height: 0 }}
                animate={{ height: '100%' }}
                transition={{ delay: i * 0.1 + 0.2 }}
              />
            )}
          </motion.div>
        ))}
      </div>

      {/* Controls */}
      <div className="flex items-center justify-center space-x-4">
        <button
          onClick={removeGlass}
          className="p-2 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors"
          disabled={glasses === 0}
        >
          <Minus size={16} className="text-fitness-text" />
        </button>
        
        <div className="text-sm text-fitness-text/60">
          {Math.round(progress)}% of daily goal
        </div>
        
        <button
          onClick={addGlass}
          className="p-2 bg-blue-500 hover:bg-blue-600 text-white rounded-full transition-colors"
        >
          <Plus size={16} />
        </button>
      </div>
    </motion.div>
  )
}