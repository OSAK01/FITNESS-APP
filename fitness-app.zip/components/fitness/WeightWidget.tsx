"use client"

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Scale, TrendingDown } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer } from 'recharts'

export function WeightWidget() {
  console.log("WeightWidget component rendered")

  const [currentWeight] = useState(72.5)
  const [goalWeight] = useState(70)
  
  const weightData = [
    { date: 'Mon', weight: 73.2 },
    { date: 'Tue', weight: 73.0 },
    { date: 'Wed', weight: 72.8 },
    { date: 'Thu', weight: 72.6 },
    { date: 'Fri', weight: 72.5 },
  ]

  const difference = currentWeight - goalWeight
  const progress = Math.max(0, 100 - (difference / goalWeight) * 100)

  return (
    <motion.div 
      className="bg-white rounded-xl shadow-lg p-6 border border-gray-100"
      whileHover={{ y: -2 }}
      transition={{ duration: 0.2 }}
    >
      <div className="flex items-center space-x-3 mb-4">
        <div className="bg-fitness-accent/10 p-2 rounded-lg">
          <Scale className="text-fitness-accent" size={24} />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-fitness-text">Weight Progress</h3>
          <p className="text-sm text-fitness-text/60">Track your journey</p>
        </div>
      </div>

      <div className="flex justify-between items-center mb-4">
        <div className="text-center">
          <motion.div 
            className="text-2xl font-bold text-fitness-accent"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            {currentWeight} kg
          </motion.div>
          <div className="text-xs text-fitness-text/60">Current</div>
        </div>
        
        <div className="text-center">
          <div className="text-lg font-semibold text-fitness-text/70">
            {goalWeight} kg
          </div>
          <div className="text-xs text-fitness-text/60">Goal</div>
        </div>
      </div>

      {/* Mini Chart */}
      <div className="h-20 mb-4">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={weightData}>
            <XAxis dataKey="date" hide />
            <YAxis hide domain={['dataMin - 0.5', 'dataMax + 0.5']} />
            <Line 
              type="monotone" 
              dataKey="weight" 
              stroke="#f97316" 
              strokeWidth={2}
              dot={{ fill: '#f97316', strokeWidth: 2, r: 3 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="flex items-center justify-between text-sm">
        <div className="flex items-center space-x-1 text-fitness-success">
          <TrendingDown size={14} />
          <span>-0.7 kg this week</span>
        </div>
        <span className="text-fitness-text/60">
          {difference.toFixed(1)} kg to goal
        </span>
      </div>
    </motion.div>
  )
}