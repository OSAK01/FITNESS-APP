"use client"

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Clock, User, Heart, MessageCircle, Share2, Bookmark } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface BlogPost {
  id: string
  title: string
  excerpt: string
  author: string
  readTime: string
  category: string
  image: string
  likes: number
  comments: number
  publishedAt: string
}

export function BlogSection() {
  console.log("BlogSection component rendered")

  const [posts] = useState<BlogPost[]>([
    {
      id: '1',
      title: '10 High-Protein Breakfast Ideas to Fuel Your Morning',
      excerpt: 'Start your day right with these delicious and nutritious breakfast options that will keep you energized and satisfied until lunch.',
      author: 'Sarah Johnson',
      readTime: '5 min read',
      category: 'Nutrition',
      image: '/api/placeholder/400/250',
      likes: 124,
      comments: 18,
      publishedAt: '2 hours ago'
    },
    {
      id: '2', 
      title: 'The Science Behind HIIT: Why It Works So Well',
      excerpt: 'Discover the research-backed benefits of High-Intensity Interval Training and how to incorporate it into your fitness routine.',
      author: 'Dr. Mike Chen',
      readTime: '8 min read',
      category: 'Workout',
      image: '/api/placeholder/400/250',
      likes: 89,
      comments: 12,
      publishedAt: '1 day ago'
    },
    {
      id: '3',
      title: 'Mindful Eating: Transform Your Relationship with Food',
      excerpt: 'Learn how mindfulness can help you make better food choices and enjoy your meals more while supporting your health goals.',
      author: 'Emma Rodriguez',
      readTime: '6 min read',
      category: 'Wellness',
      image: '/api/placeholder/400/250',
      likes: 156,
      comments: 24,
      publishedAt: '3 days ago'
    },
    {
      id: '4',
      title: 'Building Muscle After 40: A Complete Guide',
      excerpt: 'Age is just a number! Discover effective strategies for building and maintaining muscle mass as you get older.',
      author: 'Tom Williams',
      readTime: '10 min read',
      category: 'Fitness',
      image: '/api/placeholder/400/250',
      likes: 203,
      comments: 31,
      publishedAt: '5 days ago'
    }
  ])

  const [selectedCategory, setSelectedCategory] = useState('All')
  const categories = ['All', 'Nutrition', 'Workout', 'Wellness', 'Fitness']

  const filteredPosts = selectedCategory === 'All' 
    ? posts 
    : posts.filter(post => post.category === selectedCategory)

  return (
    <div className="min-h-screen bg-gradient-to-br from-fitness-light to-white">
      {/* Header */}
      <motion.div 
        className="bg-white shadow-sm border-b border-gray-200 px-6 py-8"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
      >
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl font-bold text-fitness-text mb-4">
            Fitness & Wellness Blog
          </h1>
          <p className="text-lg text-fitness-text/70 max-w-2xl mx-auto">
            Expert insights, tips, and inspiration to help you achieve your health and fitness goals
          </p>
        </div>
      </motion.div>

      <div className="max-w-6xl mx-auto p-6">
        {/* Category Filter */}
        <motion.div 
          className="flex flex-wrap justify-center gap-3 mb-8"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full transition-all duration-200 ${
                selectedCategory === category
                  ? 'bg-fitness-primary text-white shadow-lg'
                  : 'bg-white text-fitness-text hover:bg-fitness-primary/10 border border-gray-200'
              }`}
            >
              {category}
            </button>
          ))}
        </motion.div>

        {/* Blog Posts Grid */}
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 gap-8"
          layout
        >
          {filteredPosts.map((post, index) => (
            <motion.article
              key={post.id}
              className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-100 hover:shadow-xl transition-shadow duration-300"
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -5 }}
            >
              {/* Featured Image */}
              <div className="relative h-48 bg-gradient-to-r from-fitness-primary/20 to-fitness-secondary/20">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center text-fitness-text/60">
                    <div className="w-16 h-16 bg-fitness-primary/20 rounded-full mx-auto mb-2 flex items-center justify-center">
                      <Heart size={24} className="text-fitness-primary" />
                    </div>
                    <p className="text-sm">Featured Image</p>
                  </div>
                </div>
                
                {/* Category Badge */}
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-fitness-primary text-white text-xs font-medium rounded-full">
                    {post.category}
                  </span>
                </div>

                {/* Bookmark */}
                <button className="absolute top-4 right-4 p-2 bg-white/80 backdrop-blur-sm rounded-full hover:bg-white transition-colors">
                  <Bookmark size={16} className="text-fitness-text" />
                </button>
              </div>

              {/* Content */}
              <div className="p-6">
                <h2 className="text-xl font-bold text-fitness-text mb-3 line-clamp-2 hover:text-fitness-primary transition-colors cursor-pointer">
                  {post.title}
                </h2>
                
                <p className="text-fitness-text/70 mb-4 line-clamp-3">
                  {post.excerpt}
                </p>

                {/* Meta Info */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3 text-sm text-fitness-text/60">
                    <div className="flex items-center space-x-1">
                      <User size={14} />
                      <span>{post.author}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock size={14} />
                      <span>{post.readTime}</span>
                    </div>
                  </div>
                  <span className="text-sm text-fitness-text/60">{post.publishedAt}</span>
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                  <div className="flex items-center space-x-4">
                    <button className="flex items-center space-x-1 text-fitness-text/60 hover:text-fitness-primary transition-colors">
                      <Heart size={16} />
                      <span className="text-sm">{post.likes}</span>
                    </button>
                    <button className="flex items-center space-x-1 text-fitness-text/60 hover:text-fitness-primary transition-colors">
                      <MessageCircle size={16} />
                      <span className="text-sm">{post.comments}</span>
                    </button>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <button className="p-2 text-fitness-text/60 hover:text-fitness-primary transition-colors">
                      <Share2 size={16} />
                    </button>
                    <Button size="sm" className="bg-fitness-primary hover:bg-fitness-primary/90">
                      Read More
                    </Button>
                  </div>
                </div>
              </div>
            </motion.article>
          ))}
        </motion.div>
      </div>
    </div>
  )
}