"use client"

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Footprints, TrendingUp } from 'lucide-react'

export function StepsWidget() {
  console.log("StepsWidget component rendered")

  const [steps] = useState(8742)
  const dailyGoal = 10000
  const progress = (steps / dailyGoal) * 100

  return (
    <motion.div 
      className="bg-white rounded-xl shadow-lg p-6 border border-gray-100"
      whileHover={{ y: -2 }}
      transition={{ duration: 0.2 }}
    >
      <div className="flex items-center space-x-3 mb-4">
        <div className="bg-fitness-secondary/10 p-2 rounded-lg">
          <Footprints className="text-fitness-secondary" size={24} />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-fitness-text">Daily Steps</h3>
          <p className="text-sm text-fitness-text/60">Stay active today</p>
        </div>
      </div>

      <div className="text-center mb-4">
        <motion.div 
          className="text-3xl font-bold text-fitness-secondary mb-1"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          {steps.toLocaleString()}
        </motion.div>
        <div className="text-sm text-fitness-text/60">of {dailyGoal.toLocaleString()} steps</div>
      </div>

      {/* Progress Bar */}
      <div className="relative h-3 bg-gray-200 rounded-full mb-4">
        <motion.div 
          className="absolute top-0 left-0 h-full bg-fitness-secondary rounded-full"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 1, ease: "easeOut" }}
        />
      </div>

      <div className="flex items-center justify-between text-sm">
        <span className="text-fitness-text/60">
          {Math.round(progress)}% complete
        </span>
        <div className="flex items-center space-x-1 text-fitness-success">
          <TrendingUp size={14} />
          <span>+15% from yesterday</span>
        </div>
      </div>
    </motion.div>
  )
}