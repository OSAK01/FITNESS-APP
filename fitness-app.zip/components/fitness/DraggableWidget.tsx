"use client"

import { useRef } from 'react'
import { useDrag, useDrop } from 'react-dnd'
import { motion } from 'framer-motion'
import { GripVertical } from 'lucide-react'

interface DraggableWidgetProps {
  id: string
  index: number
  moveWidget: (dragIndex: number, hoverIndex: number) => void
  children: React.ReactNode
  viewMode: 'grid' | 'list'
}

export function DraggableWidget({ 
  id, 
  index, 
  moveWidget, 
  children, 
  viewMode 
}: DraggableWidgetProps) {
  const ref = useRef<HTMLDivElement>(null)

  console.log("DraggableWidget rendered:", { id, index, viewMode })

  const [{ isDragging }, drag] = useDrag({
    type: 'widget',
    item: { id, index },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  })

  const [, drop] = useDrop({
    accept: 'widget',
    hover: (item: { id: string; index: number }) => {
      if (!ref.current) return
      
      const dragIndex = item.index
      const hoverIndex = index

      if (dragIndex === hoverIndex) return

      console.log("Widget hover:", { dragIndex, hoverIndex })
      moveWidget(dragIndex, hoverIndex)
      item.index = hoverIndex
    },
  })

  drag(drop(ref))

  return (
    <motion.div
      ref={ref}
      className={`
        relative group cursor-move
        ${isDragging ? 'opacity-50' : 'opacity-100'}
        ${viewMode === 'list' ? 'w-full' : ''}
      `}
      layout
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.2 }}
    >
      <div className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
        <div className="bg-white/80 backdrop-blur-sm rounded-md p-1">
          <GripVertical size={16} className="text-fitness-text/60" />
        </div>
      </div>
      
      {children}
    </motion.div>
  )
}