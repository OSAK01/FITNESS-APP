"use client"

import { motion } from 'framer-motion'

interface GameOverScreenProps {
  score: number
  onRestart: () => void
}

export function GameOverScreen({ score, onRestart }: GameOverScreenProps) {
  console.log("GameOverScreen rendered:", { score })

  const getScoreMessage = (score: number) => {
    if (score >= 500) return "Incredible! You're a clicking master!"
    if (score >= 300) return "Amazing! Great reflexes!"
    if (score >= 200) return "Well done! Good job!"
    if (score >= 100) return "Not bad! Keep practicing!"
    return "Good try! You'll get better!"
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-game-bg via-purple-900 to-game-bg flex items-center justify-center">
      <motion.div 
        className="text-center max-w-md mx-auto p-8"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
      >
        <motion.h1 
          className="text-5xl font-bold text-game-warning mb-4"
          initial={{ y: -50 }}
          animate={{ y: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          Game Over!
        </motion.h1>
        
        <motion.div 
          className="mb-6"
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
        >
          <div className="text-lg text-game-text/80 mb-2">Final Score</div>
          <div className="text-6xl font-bold text-game-success mb-4">{score}</div>
          <div className="text-game-text/60">{getScoreMessage(score)}</div>
        </motion.div>

        <motion.button
          onClick={onRestart}
          className="px-8 py-4 bg-game-circle hover:bg-cyan-400 text-game-bg font-bold text-xl rounded-full transition-all duration-200 transform hover:scale-105 shadow-lg"
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.5 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Play Again
        </motion.button>
      </motion.div>
    </div>
  )
}