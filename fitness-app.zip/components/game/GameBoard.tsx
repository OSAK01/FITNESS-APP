"use client"

import { useState, useEffect, useCallback } from 'react'
import { AnimatePresence } from 'framer-motion'
import { Circle } from './Circle'
import { ScoreBoard } from './ScoreBoard'
import { GameOverScreen } from './GameOverScreen'

interface CircleData {
  id: string
  x: number
  y: number
  createdAt: number
}

export function GameBoard() {
  const [circles, setCircles] = useState<CircleData[]>([])
  const [score, setScore] = useState(0)
  const [gameActive, setGameActive] = useState(true)
  const [missedCount, setMissedCount] = useState(0)
  const [level, setLevel] = useState(1)
  const [gameStarted, setGameStarted] = useState(false)

  console.log("GameBoard state:", { circles: circles.length, score, gameActive, missedCount, level })

  const spawnInterval = Math.max(800 - (level * 50), 300) // Faster spawning as level increases
  const circleLifespan = Math.max(3000 - (level * 100), 1500) // Shorter lifespan as level increases

  const spawnCircle = useCallback(() => {
    if (!gameActive) return

    const newCircle: CircleData = {
      id: Math.random().toString(36).substr(2, 9),
      x: Math.random() * (window.innerWidth - 100),
      y: Math.random() * (window.innerHeight - 200) + 100,
      createdAt: Date.now(),
    }

    console.log("Spawning new circle:", newCircle)
    setCircles(prev => [...prev, newCircle])
  }, [gameActive])

  const handleCircleClicked = useCallback((id: string) => {
    console.log("Circle clicked handler:", id)
    setCircles(prev => prev.filter(circle => circle.id !== id))
    setScore(prev => {
      const newScore = prev + 10
      console.log("Score updated:", newScore)
      return newScore
    })
  }, [])

  const handleCircleMissed = useCallback((id: string) => {
    console.log("Circle missed handler:", id)
    setCircles(prev => prev.filter(circle => circle.id !== id))
    setMissedCount(prev => {
      const newMissedCount = prev + 1
      console.log("Missed count updated:", newMissedCount)
      if (newMissedCount >= 5) {
        console.log("Game over - too many misses")
        setGameActive(false)
      }
      return newMissedCount
    })
  }, [])

  const startGame = () => {
    console.log("Starting new game")
    setGameStarted(true)
    setGameActive(true)
    setScore(0)
    setMissedCount(0)
    setLevel(1)
    setCircles([])
  }

  const resetGame = () => {
    console.log("Resetting game")
    setGameStarted(false)
    setGameActive(false)
    setScore(0)
    setMissedCount(0)
    setLevel(1)
    setCircles([])
  }

  // Level progression
  useEffect(() => {
    const newLevel = Math.floor(score / 100) + 1
    if (newLevel !== level) {
      console.log("Level up:", newLevel)
      setLevel(newLevel)
    }
  }, [score, level])

  // Spawn circles
  useEffect(() => {
    if (!gameActive || !gameStarted) return

    console.log("Setting up spawn interval:", spawnInterval)
    const interval = setInterval(spawnCircle, spawnInterval)
    return () => {
      console.log("Clearing spawn interval")
      clearInterval(interval)
    }
  }, [gameActive, gameStarted, spawnCircle, spawnInterval])

  if (!gameStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-game-bg via-purple-900 to-game-bg flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-6xl font-bold text-game-text mb-4 bg-gradient-to-r from-game-circle to-game-success bg-clip-text text-transparent">
            Circle Click Challenge
          </h1>
          <p className="text-xl text-game-text/80 mb-8 max-w-md">
            Click the circles before they disappear! Don't miss more than 5 or it's game over.
          </p>
          <button
            onClick={startGame}
            className="px-8 py-4 bg-game-circle hover:bg-cyan-400 text-game-bg font-bold text-xl rounded-full transition-all duration-200 transform hover:scale-105 shadow-lg"
          >
            Start Game
          </button>
        </div>
      </div>
    )
  }

  if (!gameActive) {
    return <GameOverScreen score={score} onRestart={resetGame} />
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-game-bg via-purple-900 to-game-bg relative overflow-hidden">
      <ScoreBoard score={score} missedCount={missedCount} level={level} />
      
      <AnimatePresence>
        {circles.map((circle) => (
          <Circle
            key={circle.id}
            id={circle.id}
            x={circle.x}
            y={circle.y}
            onClicked={handleCircleClicked}
            onMissed={handleCircleMissed}
            lifespan={circleLifespan}
          />
        ))}
      </AnimatePresence>
    </div>
  )
}