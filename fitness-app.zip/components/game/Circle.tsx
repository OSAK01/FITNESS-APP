"use client"

import { motion } from 'framer-motion'
import { useEffect } from 'react'

interface CircleProps {
  id: string
  x: number
  y: number
  onClicked: (id: string) => void
  onMissed: (id: string) => void
  lifespan: number
}

export function Circle({ id, x, y, onClicked, onMissed, lifespan }: CircleProps) {
  console.log("Circle rendered:", { id, x, y, lifespan })

  useEffect(() => {
    console.log("Circle timeout started for:", id, "lifespan:", lifespan)
    const timer = setTimeout(() => {
      console.log("Circle timeout expired for:", id)
      onMissed(id)
    }, lifespan)

    return () => {
      console.log("Circle timeout cleared for:", id)
      clearTimeout(timer)
    }
  }, [id, onMissed, lifespan])

  const handleClick = () => {
    console.log("Circle clicked:", id)
    onClicked(id)
  }

  return (
    <motion.div
      className="absolute cursor-pointer"
      style={{ left: x, top: y }}
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      exit={{ scale: 0, opacity: 0 }}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      onClick={handleClick}
    >
      <div className="w-16 h-16 bg-game-circle rounded-full shadow-lg animate-circle-pulse border-2 border-white/20 flex items-center justify-center">
        <div className="w-12 h-12 bg-gradient-to-br from-game-circle to-cyan-400 rounded-full" />
      </div>
    </motion.div>
  )
}