"use client"

import { motion } from 'framer-motion'

interface ScoreBoardProps {
  score: number
  missedCount: number
  level: number
}

export function ScoreBoard({ score, missedCount, level }: ScoreBoardProps) {
  console.log("ScoreBoard rendered:", { score, missedCount, level })

  const missedDots = Array.from({ length: 5 }, (_, i) => i < missedCount)

  return (
    <motion.div 
      className="fixed top-4 left-4 right-4 flex justify-between items-center bg-black/20 backdrop-blur-sm rounded-2xl p-4 z-10"
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="flex items-center space-x-6">
        <motion.div 
          className="text-center"
          key={score}
          initial={{ scale: 1 }}
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ duration: 0.3 }}
        >
          <div className="text-sm text-game-text/60 font-medium">SCORE</div>
          <div className="text-2xl font-bold text-game-success">{score}</div>
        </motion.div>

        <motion.div 
          className="text-center"
          key={level}
          initial={{ scale: 1 }}
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ duration: 0.3 }}
        >
          <div className="text-sm text-game-text/60 font-medium">LEVEL</div>
          <div className="text-2xl font-bold text-game-circle">{level}</div>
        </motion.div>
      </div>

      <div className="text-center">
        <div className="text-sm text-game-text/60 font-medium mb-1">MISSES</div>
        <div className="flex space-x-1">
          {missedDots.map((filled, index) => (
            <motion.div
              key={index}
              className={`w-3 h-3 rounded-full ${
                filled ? 'bg-game-warning' : 'bg-white/20'
              }`}
              initial={{ scale: 0 }}
              animate={{ scale: filled ? [1, 1.3, 1] : 1 }}
              transition={{ duration: 0.3 }}
            />
          ))}
        </div>
      </div>
    </motion.div>
  )
}