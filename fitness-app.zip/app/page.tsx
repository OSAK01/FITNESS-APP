import { FitnessApp } from '@/components/fitness/FitnessApp'

export default function Home() {
  return <FitnessApp />
}
